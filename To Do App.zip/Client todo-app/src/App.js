import "./App.css";
import {useSelector} from "react-redux";
import TodosList from "./components/TodosList.jsx";
import AddTodo from "./components/AddTodo.jsx";
import Filters from "./components/Filters.jsx";
import {useState, useEffect} from "react";
import Button from "react-bootstrap/Button";
import Container from "react-bootstrap/Container";
import Row from "react-bootstrap/Row";
import Col from "react-bootstrap/Col";

function App() {
  const [state, setState] = useState({
    show: false,
    filterQuery: "&name=&priority=-1&done=-1",
    page: 1,
  });

  function showModal(e) {
    setState({
      ...state,
      show: !state.show,
    });
  }

  function handleSubmit() {
    showModal();
  }
  useEffect(() => {}, [state]);

  return (
    <Container>
      <Row>
        <Col>
          <h1>App To Do</h1>
        </Col>
      </Row>
      <Row>
        <Col>
          <div>
            <Filters state={state} setState={setState} />

            <Button
              variant="success"
              onClick={(e) => {
                showModal();
              }}
            >
              Add To Do
            </Button>
            {state.show ? (
              <AddTodo
                data={state}
                handleSubmit={handleSubmit}
                setState={setState}
              />
            ) : null}
            <TodosList data={state} setState={setState} />
          </div>
        </Col>
      </Row>
    </Container>
  );
}

export default App;
