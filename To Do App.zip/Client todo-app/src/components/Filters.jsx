import React, {useState} from "react";
import {useDispatch} from "react-redux";
import Button from "react-bootstrap/Button";
import Form from "react-bootstrap/Form";

const Filters = ({state, setState}) => {
  const [filters, setFilters] = useState({
    name: "",
    priority: -1,
    done: -1,
  });

  const handleInputChange = (event) => {
    const {name, value} = event.target;
    setFilters({...filters, [name]: value});
  };

  function sendFilters() {
    let filterQuery =
      "&name=" +
      filters.name +
      "&priority=" +
      filters.priority +
      "&done=" +
      filters.done;
    setState({
      ...state,
      filterQuery: filterQuery,
      page: 1,
    });
  }

  return (
    <div>
      <h3>Filters</h3>
      <div>
        <label htmlFor="name">Name:</label>
        <Form.Control type="text" name="name" onChange={handleInputChange} />
      </div>
      <div>
        <label htmlFor="priority">Priority:</label>
        <Form.Select name="priority" id="priority" onChange={handleInputChange}>
          <option value={-1}>All</option>
          <option value={0}>Low</option>
          <option value={1}>Medium</option>
          <option value={2}>High</option>
        </Form.Select>
      </div>
      <div>
        <label htmlFor="done">Status:</label>
        <Form.Select name="done" id="done" onChange={handleInputChange}>
          <option value={-1}>All</option>
          <option value={1}>Done</option>
          <option value={0}>Not Done</option>
        </Form.Select>
      </div>
      <Button variant="primary" onClick={sendFilters}>
        Search
      </Button>
      <br />
      &nbsp;
    </div>
  );
};

export default Filters;
