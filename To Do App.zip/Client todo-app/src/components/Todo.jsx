import React, {useEffect, useState, useCallback} from "react";
import {useDispatch} from "react-redux";
import {
  retrieveTodos,
  findTodoByName,
  deleteTodo,
  markAsDone,
  markAsUndone,
  findById,
} from "../slices/todosSlice";
import {findByDisplayValue} from "@testing-library/react";
import {useNavigate} from "react-router-dom";
import UpdateTodo from "./UpdateTodo";
import Button from "react-bootstrap/Button";
import Form from "react-bootstrap/Form";

function Todo({data}) {
  const [todo, setTodo] = useState(data);
  const dispatch = useDispatch();

  function updateDone() {
    if (todo.done) {
      dispatch(markAsUndone(todo.id))
        .unwrap()
        .then((data) => {
          setTodo({...todo, done: data.done});
        });
    } else {
      dispatch(markAsDone(todo.id))
        .unwrap()
        .then((data) => {
          setTodo({...todo, done: data.done});
        });
    }
  }
  const [state, setState] = useState({show: false});

  useEffect(() => {
    setTodo(data);
  }, [setTodo, state]);

  const removeTodo = () => {
    dispatch(deleteTodo(todo.id))
      .unwrap()
      .then(() => {})
      .catch((e) => {
        console.log(e);
      });
  };

  function showModal(e) {
    setState({
      show: !state.show,
    });
  }

  function handleSubmit() {
    showModal();
  }
  useEffect(() => {}, [state]);

  return (
    <>
      {todo ? (
        <tr>
          <th scope="row">
            <Form.Check
              inline
              id="done"
              name="done"
              checked={todo.done}
              onChange={updateDone}
            />
          </th>
          <td>{todo.name}</td>
          <td>
            {todo.priority == 0
              ? "Low"
              : todo.priority == 1
              ? "Medium"
              : "High"}
          </td>
          <td>{todo.dueDate ? todo.dueDate.slice(0, 10) : "-"}</td>
          <td>
            <Button
              variant="primary"
              onClick={(e) => {
                showModal();
              }}
            >
              Edit
            </Button>{" "}
            {state.show ? (
              <UpdateTodo
                show={state.show}
                data={todo}
                handleSubmit={handleSubmit}
              />
            ) : null}
            <Button variant="danger" onClick={removeTodo}>
              Delete
            </Button>
          </td>
        </tr>
      ) : (
        <div>"missing data"</div>
      )}
    </>
  );
}

export default Todo;
