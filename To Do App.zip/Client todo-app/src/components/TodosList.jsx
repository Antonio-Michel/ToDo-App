import React, {useState, useEffect, useCallback} from "react";
import {useSelector, useDispatch} from "react-redux";
import {
  retrieveTodos,
  findTodoByName,
  deleteTodo,
  markAsDone,
  markAsUndone,
  findById,
} from "../slices/todosSlice";
import Todo from "./Todo";
import Table from "react-bootstrap/Table";
import Pagination from "react-bootstrap/Pagination";
import Container from "react-bootstrap/Container";
import Row from "react-bootstrap/Row";
import Col from "react-bootstrap/Col";

function TodosList({data, setState}) {
  console.log(data);
  const todos = useSelector((state) => state.todos);

  const dispatch = useDispatch();

  const [page, setPage] = useState(1);

  const initialFetch = useCallback(() => {
    dispatch(retrieveTodos(data.page + data.filterQuery));
  });

  useEffect(() => {
    initialFetch();
  }, [data]);

  function prevPage() {
    if (data.page > 1) {
      setState({
        ...data,
        page: data.page - 1,
      });
    }
  }
  function nextPage() {
    setState({
      ...data,
      page: data.page + 1,
    });
  }

  return (
    <Container>
      <Row>
        <Col>
          <div>
            <br />
            <Table responsive striped bordered hover>
              <thead>
                <tr>
                  <th scope="col">Done</th>
                  <th scope="col">Task</th>
                  <th scope="col">Priority</th>
                  <th scope="col">Due Date</th>
                  <th scope="col">Actions</th>
                </tr>
              </thead>
              <tbody>
                {todos.length
                  ? todos.map((todo) => {
                      return <Todo key={todo.id} data={todo} />;
                    })
                  : null}
              </tbody>
            </Table>
            <Row className="justify-content-md-center">
              <Col md="auto">
                <Pagination>
                  <Pagination.Item hidden={data.page === 1} onClick={prevPage}>
                    &lt;
                  </Pagination.Item>
                  <Pagination.Item active={true}>{data?.page}</Pagination.Item>
                  <Pagination.Item onClick={nextPage}>&gt;</Pagination.Item>
                </Pagination>
              </Col>
            </Row>
          </div>
        </Col>
      </Row>
    </Container>
  );
}

export default TodosList;
