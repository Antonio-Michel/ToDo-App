import React from "react";
import ReactDOM, {createRoot} from "react-dom/client";
import "./index.css";
import App from "./App";
import "bootstrap/dist/css/bootstrap.min.css";

import store from "./store";
import {Provider} from "react-redux";

const container = document.getElementById("root");

const root = ReactDOM.createRoot(container);
root.render(
  <Provider store={store}>
    <App />
  </Provider>
);
